/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicsstore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author Zachary Kirchens
 */
public class ElectronicsStore implements Serializable{

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    static Scanner kb=new Scanner(System.in);
    static Account currUser;
    static UserList ulist=new UserList();
    static ArrayList<StoreObject> currInventory;
    static Inventory inventoryList[]={
    new Inventory("TV"), 
    new Inventory("Cell Phones"),
    new Inventory("Wearables"),
    new Inventory("PC & Accessories"),
    new Inventory("Video Game Consoles"),
    new Inventory("Cameras"),
    new Inventory("Speakers"),
    new Inventory("Car Electronics"),
    new Inventory("Musical Instruments"),
    new Inventory("Office Electronics")};
    
    
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
        loadInventories();
        ulist=ulist.loadUsers();
        ulist.printUsers();
        Menu();
        saveInventories();
        ulist.saveUsers();
    }
    
    
    //Main Menu:----------------------------------------------------------------
    public static void Menu()
    {
        //Get Choice
        boolean choiceMade=false;
        do
        {
            System.out.println("Welcome to Electronic Store!");
        if(currUser!=null){System.out.println("Current User: "+currUser.getEmail());}
        
        //All users
        System.out.printf(""
                + "%20s - %2s\n"
                + "%20s - %2s\n"
                + "%20s - %2s\n"
                + "%20s - %2s\n",
                "Search for object", "SO",
                "Login User", "LU",
                "Logout user", "XU",
                "View Inventory", "VI");
        
        //Current User is an Administrator        
        if(currUser!=null && currUser.getPermissions()>0)
        {
            System.out.printf("%20s - %2s\n","Admin Menu", "AM");
        }
        
            //Exit Statement
            System.out.printf("%20s - %2s\n","Exit", "EX");
            
            // Actual user input
            System.out.print("please type option:");
            String str=kb.next();
            kb.nextLine();
            System.out.println("\n\n");
            
            //Switch case
            switch(str.toLowerCase())
            {

                case("so"):
                    {//Search for Object - SO
                        System.out.println("This setting isn't available at the current moment");
                        break;
                    }

                
                case("am"):
                    {// View Inventory - VI
                        if(currUser.getPermissions()>0)
                        {
                            adminMenu();
                        }
                        else
                        {
                            System.out.println("This is not an option");
                        }
                        break;
                    }
                        
                case("vi"):
                    {// View Inventory - VI
                        browseInventoryList();
                        break;
                    }

                case("ex"):
                    {// Exit Program - EX
                        System.out.println("Exiting Program:");
                        choiceMade = true;
                        break;
                    }
                default:
                    {
                        System.out.println("This is not an option");
                    }
            }
            System.out.println("\n\n");
        }
        while(!choiceMade);
        
    }
    
    
    //Sub-Menus:----------------------------------------------------------------
    public static void UserOptions()
    {
        
        boolean userOptionExit=false;
        do
        {
            if(currUser==null)
            {
                System.out.printf("%20s - %2s\n","Login User", "login");
            }
            else
            {
                System.out.printf("%20s - %2s\n","Logout User", "logout");
                System.out.printf("%20s - %2s\n","View Info", "info");
            }
            System.out.printf("%20s - %2s\n","Go back", "back");
            switch(getString(kb,"option"))
            {
                case("login"):
                    {//Login User - login
                        if(currUser==null)
                        {
                           currUser=loginUser(); 
                        }
                        else System.out.println("There is already a user logged in!"
                                + "\nLogout first!");
                        break;
                    }
                        
                case("logout"):
                    {// Logout user - logout
                        if(currUser!=null)
                        {
                            currUser=null;
                        }
                        else System.out.println("This is not a valid option!");
                        break;
                    }
                
                case("info"):
                    {// Logout user - logout
                        if(currUser!=null)
                        {
                            System.out.println(currUser.toString());
                        }
                        else System.out.println("This is not a valid option!");
                        break;
                    }
                default:
                {
                    System.out.println("This is not a valid option!");
                }
            }
        }while(!userOptionExit);
    }
    public static void printInventoryOptions()
    {
        
    }
    
    //Standard Account Functions------------------------------------------------
    public static Account loginUser()
    {
        Account tempAccount=null;
                        System.out.println("Logging in user:");
                        tempAccount=ulist.Search(getString(kb,"login email"));
                        if(tempAccount!=null)
                        {
                            System.out.println("Account Found!");
                            boolean successful=false;
                            do
                            {
                                if(getString(kb,"your password").equals(tempAccount.getPassword()))
                                {
                                    System.out.println("password correct!");
                                    return tempAccount;
                                }
                                else
                                {
                                    System.out.print("Do you want to try again?\n y/n");
                                    if(getString(kb,"your choice").equals("n"))
                                    {
                                        successful=true;
                                    }
                                }
                            }
                            while(!successful);
                        }
                        else
                        {
                            System.out.print("Account Not Found\nCreate Account?\ny/n:");
                            if(kb.next().equals("y"))
                            {
                                tempAccount=new StandardAccount(
                                getString(kb,"your first name"),
                                        getString(kb,"your last name"),
                                        getString(kb,"your middle initial").charAt(0),
                                        getString(kb,"your gender"),
                                        getString(kb,"your password"),
                                        getString(kb,"your email"),
                                        getString(kb,"paypal account name"));
                                ulist.addAccount(tempAccount);
                                return tempAccount;
                            }
                            else
                            {
                                System.out.println("Exiting login screen");
                            }
                            return null;
                        }
                        return null;
    }
    public static void browseInventoryList()
    {
        boolean inventIsChosen=false;
        do
        {
            for(int x=0;x<inventoryList.length;x++)
            {
                System.out.printf("%-30s - %1d\n%25s\n\n",
                        inventoryList[x].getName(),
                        x,inventoryList[x].getDescription());
            }
            System.out.printf("%-30s - %2s\n\n","Back","-1");
            int choice=getInt(kb,"desired Option");
            try
            {
                currInventory=inventoryList[choice].getList();
                browseCurrentInventory();
                
            }
            catch(Exception e)
            {
                if(choice==-1)
                {
                    inventIsChosen=true;
                    System.out.println("Returning to previous menu");
                }
                else
                {
                    System.out.println("This is not a valid option");
                }
            }
        }while(!inventIsChosen);
        
    }
    public static void browseCurrentInventory()
    {
        boolean iWannaLook=false;
        do
        {
            for(int x=0; x<currInventory.size(); x++)
            {
                System.out.printf("%20s - %3d\n"
                        + "%12s\n",
                        currInventory.get(x).getName(),x,
                        currInventory.get(x).getDescription());
            }
            System.out.println("To look at a particular object, type it's number\n"
                    + "To go back, type -1");
            int choice=getInt(kb,"desired Option");
            try
            {
                lookAtStoreObject(currInventory.get(choice));
            }
            catch(Exception e)
            {
                if(choice==-1)
                {
                    iWannaLook=true;
                }
                else
                {
                    System.out.println("This is not a valid option!");
                }
                
            }
            
            
        }while(!iWannaLook);
        
    }
    public static void lookAtStoreObject(StoreObject item)
    {
        System.out.println(item.toString());
        if(currUser!=null&&currUser.getPermissions()<1)
        {
            System.out.println("Add Object to Cart?");
            System.out.print("y/n?>>");
            String choice=kb.next();
            if(choice.toLowerCase().equals("y"))
            {
                currUser.addToCart(item);
            }
        }
    }
    
    //Adminstrative Functions---------------------------------------------------
    public static void adminMenu()
    {
        boolean adminChoiceMade;
        do
        {
            System.out.printf(""
                    + "%20s - %2s\n"
                    + "%20s - %2s\n"
                    + "%20s - %2s\n"
                    + "%20s - %2s\n"
                    + "%20s - %2s\n",
                    "Add StoreObject", "AS",
                    "Delete StoreObject", "DS",
                    "Delete User", "DU",
                    "Add Administrator", "AA",
                    "Previous Menu", "BK");
            System.out.print("please type option:");
                String str=kb.next();
                kb.nextLine();
                System.out.println("\n\n");
                switch(str.toLowerCase())
                {

                    case("so"):
                        {//Search for Object - SO
                            System.out.println("This setting isn't available at the current moment");
                            adminChoiceMade = false;
                            break;
                        }
                case("bk"):
                    {// Exit Program - EX
                        System.out.println("Exiting Program:");
                        adminChoiceMade = true;
                        break;
                    }
                default:
                    {
                        System.out.println("This is not an option");
                        adminChoiceMade = false;
                    }
            }
            System.out.println("\n\n");
        }
        while(!adminChoiceMade);
    }
    public static void addObject(Inventory iDesiredInventory)
    {
        
    }
    
    //File loading/Saving related methods---------------------------------------
    public static void loadInventories()
    {
        for(int x=0;x<inventoryList.length;x++)
        {
            inventoryList[x].loadInventory();
        }
    }
    public static void saveInventories()
    {
        for(int x=0;x<inventoryList.length;x++)
        {
            inventoryList[x].saveInventory();
        }
    }
    
    
    //Input/ Input Validation---------------------------------------------------
    public static int getInt(Scanner kb, String str)
    {
        try
        {
            System.out.println("Type an integer value for the "+str+".");
            return kb.nextInt();
        }
        catch(java.util.InputMismatchException e)
        {
           System.out.println("This is not an integer value!\n"
                            + "An integer value is a number that is not a decimal.");
           kb.nextLine();
           return getInt(kb,str);
        }
        
    }
    public static double getDouble(Scanner kb, String str)
    {
        try
        {
            System.out.println("Type an decimal value for the "+str+".");
            return kb.nextDouble();
        }
        catch(java.util.InputMismatchException e)
        {
           System.out.println("This is not an decimal value!\n"
                            + "An decimal value is any number in the real plane!");
           kb.nextLine();
           return getDouble(kb,str);
        }
    }
    public static String getString(Scanner kb, String str)
    {
        try
        {
            System.out.println("Type an string value for the "+str+".");
            return kb.next();
        }
        catch(java.util.InputMismatchException e)
        {
           System.out.println("This is not an string value!\n"
                            + "I have no clue how you managed this!");
           kb.nextLine();
           return getString(kb,str);
        }
    }
    
}
