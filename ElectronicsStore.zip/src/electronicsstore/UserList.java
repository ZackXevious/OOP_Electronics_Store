package electronicsstore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @authors Zachary Kirchens, Gregory Salazar
 */
public class UserList //Class name
        implements Serializable //implemented interface
{

    //Variables-----------------------------------------------------------------
    private final ArrayList<Account> listofAccounts;

    //Constructors--------------------------------------------------------------
    public UserList() {/*Default Constructor*/

        listofAccounts = new ArrayList<>();
    }

    //Mutators------------------------------------------------------------------
    public void addAccount(Account aUser) {/*AddAccount Method: Adds an account to the current list*/

        listofAccounts.add(aUser);
    }

    public void RemoveAccount(String sSearch, Account currAccount) {
        /*Remove Account Method: 
         Takes a string argument, then loops through the UserList until a user
         with said email is found, then, if the permissions for the accessing 
         account are good, then the found account is removed from the list.*/

        if (currAccount.getPermissions() > 0) {
            listofAccounts.remove(this.Search(sSearch));
        } else {
            System.out.println("Insufficient permissions!");
        }
    }

    //Accessors-----------------------------------------------------------------
    public Account Search(String sSearch) {
        /*The search method: Loops through the UserList until an account with the
         argument string as it's email value is found, then returns that account.
         if an account is not found, then null is returned*/

        for (Account person : listofAccounts) {
            if (person.getEmail().equals(sSearch))//Check Name
            {
                return person;
            }

        }
        return null;
    }

    public void printUsers() {
        /*The search method: Loops through the UserList until an account with the
         argument string as it's email value is found, then returns that account.
         if an account is not found, then null is returned*/

        for (Account person : listofAccounts) {
            System.out.println(person.getEmail());
        }
    }

    //FileSystem Interaction----------------------------------------------------
    public void saveUsers() {
        /*The saveUsers Method: Implements various classes to save the current
         UserList as a file, for easier access in the future.*/

        try (FileOutputStream fileOut = new FileOutputStream(new File("uList.ser")); ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
            out.writeObject(this);
        } catch (IOException i) {
            System.out.println("Could Not Write file");
        }
    }

    public UserList loadUsers() {
        /*The loadUsers Method: Implements various classes to load the current
         UserList as a file, for easier access and less hardcoding*/

        try (FileInputStream fileIn = new FileInputStream("uList.ser");
                ObjectInputStream in = new ObjectInputStream(fileIn)) {
            return (UserList) in.readObject();
        } catch (IOException i) {
            System.out.println("Could Not Load File uList.ser");
        } catch (ClassNotFoundException c) {
            System.out.println("Class not found");
        }
        return null;
    }
}
