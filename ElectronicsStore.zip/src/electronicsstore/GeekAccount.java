/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicsstore;

/**
 * Electronics Store Class: StandardAccount Description: (Type description here)
 * Notes: This is the superclass for the Geek account (GeekAccount.java), and as
 * such is a requirement for that class
 *
 * @authors Zachary Kirchens, Gregory Salazar
 */
public class GeekAccount //Class Name
        extends Account //Super Class
{

    //Variables-----------------------------------------------------------------
    private String paypalAccount;
    private int geekPoints;

    //Constructors--------------------------------------------------------------
    public GeekAccount() {
        /*
         Constructor for GeekAccount, receives and sets all the same infomration as the parent class Account
        Also sets geekPoints to zero by default
         */
        super();
        geekPoints = 0;
        this.setPermissions(0);
        this.setPayPal("HerpDerp");
    }

    public GeekAccount(String sFirstName, String sLastName, char cMiddleInitial,
            char cGender, String sPassword, String sEmail,
            String sPayAccount) {
        /*
         Constructor for GeekAccount, receives and sets all the same infomration as the parent class Account
        Also sets geekPoints to zero by default
         */
        super(sFirstName, sLastName, cMiddleInitial, cGender, sPassword, sEmail, sPayAccount);
        geekPoints = 0;
        this.setPermissions(0);
        this.setPayPal(sPayAccount);
    }

    @Override
    public void makePurchase() {
        /*Overrides the makePurchase() in Account class to be able to add and use geek points for the purchase*/
        if (cart.isEmpty()) {
            System.out.println("There are no items in your cart.");
            return;
        }
        double total = 0;
        int gpAdded;
        history.addAll(cart);
        for (StoreObject item : cart) {
            item.setQuantityOnHand(item.getQuantityOnHand() - 1);
            total += item.getPrice();
        }
        System.out.println("Would you like to use your Geek Points to help pay for this purchase? (Y/N)");
        if (ElectronicsStore.kb.nextLine().equalsIgnoreCase("Y")) {
            double newCost = Math.max(0, total - geekPoints);
            geekPoints -= total - newCost;
            total = newCost;
        }
        gpAdded = (int) (100 * (total % 100));  //add 100 geek points for every 100$ spent in purchase
        geekPoints += gpAdded;
        System.out.print("A purchase was made");
        if (gpAdded > 0) {
            System.out.println(" and " + gpAdded + " geek points have been added to your account!");
        } else {
            System.out.println(".");
        }
        this.clearCart();
    }
}
