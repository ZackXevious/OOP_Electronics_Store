/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicsstore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @authors Zachary Kirchens, Gregory Salazar
 */
public class Inventory implements Serializable {

    //Variables-----------------------------------------------------------------
    private String name;
    private String description;
    private final ArrayList<StoreObject> inventoryList = new ArrayList<>();

    ;
    
    
    //Constructors--------------------------------------------------------------
    public Inventory() {
        //Default constructor, sets default name and description
        this.setName("Default");
        this.setDescription("A temporary, default inventory list");
    }

    public Inventory(String sName) {
        //Constructor that allows specification of name, and sets default description
        this.setName(sName);
        this.setDescription("A temporary, default inventory list");
    }

    public Inventory(String sName, String sDescription) {
        //Constructor that specifies both name and description
        this.setName(sName);
        this.setDescription(sDescription);
    }

    public void addToInventory(StoreObject item) {/*The "addToInventory" Method: This method takes a StoreObject argument, 
         "item", which is then added to the "inventoryList" ArrayList object 
         using said object's "remove" method*/
        //If the item already exists in the inventory then the quantityOnHand variable is updated
        for (StoreObject lItem : inventoryList) {
            if (lItem.equals(item)) {
                lItem.setQuantityOnHand(lItem.getQuantityOnHand() + item.getQuantityOnHand());  //Adds the two quantities to the existing item in list
                return;
            }
        }
        inventoryList.add(item);
    }

    public void removeFromInventory(StoreObject item) {/*The "removeFromInventory" Method: This method takes a StoreObject 
         argument, "item", which is then removed from the "inventoryList" 
         ArrayList object, using said object's "remove" method*/
        inventoryList.remove(item);
    }

    public ArrayList<StoreObject> Search(String sSearch) {
        //Searches the whole inventory for any items containing the given String sSearch in the objects' names, descriptions, or item numbers.
        //Returns the items in an ArrayList
        ArrayList<StoreObject> foundItems = new ArrayList<>();
        for (StoreObject item : inventoryList) {
            if (item.getName().contains(sSearch)
                    || item.getDescription().contains(sSearch)
                    || ("" + item.getItemNumber()).contains(sSearch))//Check Name
            {
                foundItems.add(item);
            }

        }
        return foundItems;
    }

    //Mutators------------------------------------------------------------------
    public final void setName(String sName) {
        //Sets the String name to the given String sName
        name = sName;
    }

    public final void setDescription(String sDescription) {
        //Sets the String description to the given String sDescription
        description = sDescription;
    }

    //Accessors-----------------------------------------------------------------
    public String getName() {
        //Returns the String name
        return name;
    }

    public String getDescription() {
        //Returns the String description
        return description;
    }

    public StoreObject getItem(int itemNumber) {
        //Returns a copy of the item of the specified item number in the inventory
        //If no item exists by that number, returns null
        for (StoreObject item : inventoryList) {
            if (item.getItemNumber() == itemNumber) {
                return item.copy();
            }
        }
        return null;
    }

    @Override
    public String toString() {
        //Returns a String representation of the inventory as its name
        return String.format("%12s\n:", this.getName());
    }

    public void printObjects() {
        //Prints the names of all items in the inventory
        for (StoreObject item : inventoryList) {
            System.out.println(item.getName());
        }
    }

    //FileSystem Interaction----------------------------------------------------
    public void saveInventory() {
        //Saves the inventory to file
        try (FileOutputStream fileOut = new FileOutputStream(new File("" + this.getName() + ".ser")); ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
            out.writeObject(this);
            out.flush();
        } catch (IOException i) {
            System.out.println("Could Not Write file");
        }
    }

    public Inventory loadInventory() {
        //Loads the inventory from a file
        try (FileInputStream fileIn = new FileInputStream("" + this.getName() + ".ser");
                ObjectInputStream in = new ObjectInputStream(fileIn)) {
            return (Inventory) in.readObject();
        } catch (IOException i) {
            System.out.println("Could Not Load File");
        } catch (ClassNotFoundException c) {
            System.out.println("Class not found");
        }
        return null;
    }

    public ArrayList<StoreObject> getList() {
        //Returns a copy of the inventory list
        return (ArrayList<StoreObject>) inventoryList.clone();
    }
}
