/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicsstore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @authors Zachary Kirchens, Gregory Salazar
 */
public class Inventory implements Serializable {

    //Variables-----------------------------------------------------------------
    private String name;
    private String description;
    private final ArrayList<StoreObject> inventoryList = new ArrayList<>();

    ;
    
    
    //Constructors--------------------------------------------------------------
    public Inventory() {
        this.setName("Default");
        this.setDescription("A temporary, default inventory list");
    }

    public Inventory(String sName) {
        this.setName(sName);
        this.setDescription("A temporary, default inventory list");
    }

    public Inventory(String sName, String sDescription) {
        this.setName(sName);
        this.setDescription(sDescription);
    }

    public void addToInventory(StoreObject item) {/*The "addToInventory" Method: This method takes a StoreObject argument, 
         "item", which is then added to the "inventoryList" ArrayList object 
         using said object's "remove" method*/

        //If the item already exists in the inventory then the quantityOnHand variable is updated

        for (StoreObject lItem : inventoryList) {
            if (lItem.equals(item)) {
                lItem.setQuantityOnHand(lItem.getQuantityOnHand() + item.getQuantityOnHand());  //Adds the two quantities to the existing item in list
                return;
            }
        }
        inventoryList.add(item);
    }

    public void removeFromInventory(StoreObject item) {/*The "removeFromInventory" Method: This method takes a StoreObject 
         argument, "item", which is then removed from the "inventoryList" 
         ArrayList object, using said object's "remove" method*/

        inventoryList.remove(item);
    }

    public ArrayList<StoreObject> Search(String sSearch) {
        ArrayList<StoreObject> foundItems = new ArrayList<>();
        for (StoreObject item : inventoryList) {
            if (item.getName().contains(sSearch)
                    || item.getDescription().contains(sSearch)
                    || ("" + item.getItemNumber()).contains(sSearch))//Check Name
            {
                foundItems.add(item);
            }

        }
        return foundItems;
    }

    //Mutators------------------------------------------------------------------
    public final void setName(String sName) {
        name = sName;
    }

    public final void setDescription(String sDescription) {
        description = sDescription;
    }

    //Accessors-----------------------------------------------------------------
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public StoreObject getItem(int itemNumber) {
        for (StoreObject item : inventoryList) {
            if (item.getItemNumber() == itemNumber) {
                return item.copy();
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return String.format("%12s\n:", this.getName());
    }

    public void printObjects() {
        for (StoreObject item : inventoryList) {
            System.out.println(item.getName());
        }
    }

    //FileSystem Interaction----------------------------------------------------
    public void saveInventory() {

        try (FileOutputStream fileOut = new FileOutputStream(new File("" + this.getName() + ".ser")); ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
            out.writeObject(this);
            out.flush();
        } catch (IOException i) {
            System.out.println("Could Not Write file");
        }
    }

    public Inventory loadInventory() {
        try (FileInputStream fileIn = new FileInputStream("" + this.getName() + ".ser");
                ObjectInputStream in = new ObjectInputStream(fileIn)) {
            return (Inventory) in.readObject();
        } catch (IOException i) {
            System.out.println("Could Not Load File");
        } catch (ClassNotFoundException c) {
            System.out.println("Class not found");
        }
        return null;
    }

    public ArrayList<StoreObject> getList() {
        return (ArrayList<StoreObject>) inventoryList.clone();
    }
}
